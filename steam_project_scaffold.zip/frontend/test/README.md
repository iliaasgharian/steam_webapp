# Playbase — UI/UX Prototype (Light)

Open `index.html` in a browser. No build step and no server are needed.
(Fonts load from Google Fonts, so they need an internet connection.)

## Structure

```
index.html            page markup (navbar, footer, #view container) + <link>/<script> tags
css/
  variables.css       colors, radius, fonts  ← start here to change the look
  base.css            reset and base styles
  navbar.css          navbar, dropdowns, search overlay
  layout.css          containers and sections
  home.css            homepage
  components.css      game tiles / grid, page headers
  browse.css          browse page + filters
  analytics.css       analytics page
  game-detail.css     game detail page
  pages.css           about, mixer, contact
  footer.css          footer
  enhancements.css    loader, animations, hover effects
  mobile.css          mobile menu + responsive rules
  hover-and-filters.css  floating hover preview, tag filter
  hybrid.css          hybrid design system overrides
  intelligence.css    "Steam Intelligence" tab
  light-theme.css     light theme overrides (must stay last)
js/
  data.js             sample games, tags, developers, DLC, comments
  utils.js            formatters, tile builders, chart helpers
  ui.js               navbar, search, mobile menu, reveal, count-up
  router.js           #/path → page function
  pages/              one file per page (home, browse, genres, analytics, ...)
    catalog.js        SHARED layout: hero + left filter sidebar + results grid
                      (used by Browse AND all collection pages: bundles, free, top week...)
  main.js             init — keep it last
```

## Game images

`images/games/<id>.svg` is the cover (tiles, search, detail hero) and `<id>-1.svg … <id>-5.svg` are the screenshots.
The current files are generated placeholders — replace them with real art using the same names (or any extension, by setting `image` / `shots` on the game in `js/data.js`).
If an image is missing, the old colored gradient shows behind it.

## Notes

- **Order matters.** CSS files later in `index.html` override earlier ones; JS files share one global scope, so `data.js` and `utils.js` must load before the pages, and `main.js` last.
- **Add a page:** create `js/pages/yourpage.js` with a `renderYourPage()` function, add a `<script>` tag before `main.js`, and add a branch for it in `js/router.js`.
- **Change colors:** edit `css/variables.css`. Some gradients and overrides in `hybrid.css` and `light-theme.css` use their own values.

- **Filters:** the left filter sidebar lives only in `js/pages/catalog.js`. `browse.js` and `collections.js` just pass it their data and labels, so a change there applies to every page.

## Game Mixer

`js/pages/mixer.js` blends two games from their tags/genres: a concept name + pitch, shared / unique DNA tags, and the 3 closest existing games (games that share tags with BOTH picks rank first). It runs in the browser on the sample data. Later, replace `mixGames()` with a call to the backend (`POST /api/mix`: pgvector similarity + LLM text); the UI stays the same. Styles: `css/mixer.css`.

## Real sample data (10 Steam games)

`js/data-real.js` adds 20 well-known Steam games (CS2, Dota 2, PUBG, Elden Ring, Baldur's Gate 3, Cyberpunk 2077, Stardew Valley, Hollow Knight, Hades, Terraria, Apex Legends, Team Fortress 2, Rust, Portal 2, Red Dead Redemption 2, The Witcher 3, Sekiro, Civilization VI, Slay the Spire, HELLDIVERS 2) with real names and Steam header images. Most other fields were written from memory and are NOT verified — see the comment at the top of that file for exactly which fields are looked-up, remembered, estimated or placeholder.
Change `REAL_DATA_MODE` at the top of the file: `"add"` (default, next to the fake games), `"only"` (just the 10 real games) or `"off"`.
Player counts / review numbers are rounded snapshots (see the comment in the file). Requirements, DLC and comments on the detail page are still sample text.
Images: no image files are shipped for these games. `gameBg()` in `js/utils.js` tries your local `images/games/<id>.jpg` first, then four Steam CDN hosts, then the generated placeholder art. To make them always work, run `python tools/download_images.py` once (needs internet) — it saves covers, wide banners and screenshots into `images/games/`.

### Picking games in the Mixer

Clicking a slot opens `#/mixer/pick/a` (or `/b`): the same filter sidebar as "All games", but tiles show only the image and name (no hover panel, no wishlist, no link to the game page). Clicking a tile saves the pick and returns to `#/mixer`; the other slot works the same way. The tile layout is `mixPickTile()` in `js/pages/mixer.js`; `catalog.js` accepts a custom `tile` function for this.

## Using the scraped Steam data (300 games)

1. Run `python scrape_steam_games.py` (outside the site folder or inside it) → `steam_games.json`.
2. Put the JSON in `data/steam_games.json` and run `python tools/json_to_js.py` → writes `js/steam-games-data.js`.
3. Reload the site. `js/data-real.js` sees `STEAM_GAMES_DATA` and uses the scraped games instead of the 20 hand-written ones (`REAL_DATA_MODE` becomes `"only"`). Delete `js/steam-games-data.js` to go back to the hand-written games.

Real on the detail page now: description, developer, publisher, release date, platforms, categories, Steam Deck, review label, Metacritic, requirements, screenshots, 24h peak (yesterday's peak players), "View on Steam" link, DLC count.
Still sample data: bundles, analytics charts, regional prices (fixed rates), price signal, Steam Intelligence panels, site-wide numbers. Comments are hidden for scraped games (not scraped yet).
Why a `.js` file and not a direct `fetch()` of the JSON: pages opened from a folder (`file://`) cannot fetch local files. Behind a real server or the FastAPI backend you can fetch the JSON instead.
